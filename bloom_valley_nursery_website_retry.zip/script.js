
// ========== CART FUNCTIONALITY ==========
let cart = JSON.parse(localStorage.getItem("cart")) || [];

function addToCart(item, price) {
  cart.push({ item, price });
  localStorage.setItem("cart", JSON.stringify(cart));
  alert("Item added");
}

function updateCartModal() {
  const cartItems = document.getElementById("cartItems");
  cartItems.innerHTML = "";
  cart.forEach((entry, i) => {
    const li = document.createElement("li");
    li.textContent = `${entry.item} - $${entry.price.toFixed(2)}`;
    cartItems.appendChild(li);
  });
}

function clearCart() {
  cart = [];
  localStorage.removeItem("cart");
  updateCartModal();
}

function processOrder() {
  if (cart.length === 0) {
    alert("Your cart is empty");
  } else {
    alert("Thank you for your order");
    clearCart();
    document.getElementById("cartModal").style.display = "none";
  }
}

window.addEventListener("DOMContentLoaded", () => {
  const viewCartBtn = document.getElementById("viewCart");
  const cartModal = document.getElementById("cartModal");

  if (viewCartBtn) {
    viewCartBtn.addEventListener("click", () => {
      updateCartModal();
      cartModal.style.display = "block";
    });
  }

  // Close modal if clicked outside
  window.addEventListener("click", (e) => {
    if (e.target === cartModal) {
      cartModal.style.display = "none";
    }
  });
});

// ========== FORM FUNCTIONALITY ==========
window.addEventListener("DOMContentLoaded", () => {
  const feedbackForm = document.getElementById("feedbackForm");
  const formResponse = document.getElementById("formResponse");

  if (feedbackForm) {
    feedbackForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const name = document.getElementById("name").value;
      const email = document.getElementById("email").value;
      const message = document.getElementById("message").value;

      const entry = { name, email, message, submitted: new Date().toISOString() };
      localStorage.setItem("feedbackEntry", JSON.stringify(entry));
      formResponse.textContent = "Thank you for your feedback!";
      feedbackForm.reset();
    });
  }
};
